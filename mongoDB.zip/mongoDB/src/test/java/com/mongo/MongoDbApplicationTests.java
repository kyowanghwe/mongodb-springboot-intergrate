package com.mongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
